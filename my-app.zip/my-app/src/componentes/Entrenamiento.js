import "./Entrenamiento.css"
import Image from "../Imagenes/Logo2.png"
import Image2 from "../Imagenes/3.Tonificacion.png"

const Entrenamiento=()=>{
     

    return(
   <div className="PagePrincipal"> 
    
    
       <div class="encabezado">
            <header>
               <img src={Image}/>
                <ul class="Menu">
        
                    <li><a href="#">Home</a></li>
                    <li><a href="#">Nutricion</a></li>
                    <li><a href="#">Rutinas</a></li>
                    <button id ="botones" class="botones" ><a href="#">Login</a></button>
        
                </ul>
            </header>
       </div >
       <div class="Principal">
              <img src={Image2}/>
        </div>
  



      <div class="Pie">
             <footer>
    
             </footer>
       </div>
     
    </div>

    )
    
}

export default Entrenamiento ;