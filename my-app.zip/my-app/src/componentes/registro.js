import React, { useState, useEffect } from "react";
import "./registro.css";
//import conexion from './server/server.js';

const Registro = () => {
  const [usuarios, setUsuarios] = useState([]);
  const [user, setUser] = useState("");
  const [correo, setCorreo] = useState("");
  const [password, setPassword] = useState("");

  const handleRegistro = () => {
    if (user !== "" && correo !== "" && password !== "") {
      console.log(user);
      fetch('http://localhost:8801/crear', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ Usuario: user, Correo: correo, Contrasena: password })
      })
        .then((response) => {
          if (response.ok) {
            return response.json(); //parse the response to get the new user data
          } else {
            alert('No se pudo crear la cuenta');

          }
        })
        .then((data) => {
          //update the usuarios state with the new user data
          setUsuarios([...usuarios, data]);
          alert('Cuenta creada exitosamente');
        })
        .catch((error) => {
          console.error(error);
          alert('Error al crear la cuenta');
          alert(user);
          alert(correo);
          alert(password);
        });
    } else {
      alert('Debes completar todos los campos');
    }
  };
  
  

  return (
    <div className="cover">
      <h1>Registro</h1>
      <input
        type="text"
        placeholder="Usuario"
        value={user}
        onChange={(e) => setUser(e.target.value)}
      />
      <input
        type="text"
        placeholder="Correo"
        value={correo}
        onChange={(e) => setCorreo(e.target.value)}
      />
      <input
        type="password"
        placeholder="Password"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
      />
      <div className="login-btn" onClick={handleRegistro}>
        Registro
      </div>
      <p className="text">No tienes Cuenta? Registrate</p>

      <div className="alt-login">
        <div className="facebook"></div>
        <div className="google"></div>
      </div>

      <ul>
        {usuarios.map((usuario) => (
          <li key={usuario.id}>
            {usuario.nombre} - {usuario.correo}
          </li>
        ))}
      </ul>
    </div>
  );
};

export default Registro;
