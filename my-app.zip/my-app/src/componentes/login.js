
var user ,correo,password

function login(){

    var user1 ,password1

    user1= document.getElementById("usuario").value;
    password1=document.getElementById("contraseña").value;

    if(user1== "JHON"&& password1=="1234"){
        alert("iniciastes Sesion")
        window.location="../Usuario/Home-Usuario.html"
       
    }else if(user1== "ADMIN"&& password1=="12345"){
        alert("iniciastes Sesion")
        window.location="../Usuario/Usuario1.html"
       
    }else if(user1== "ENTRENADOR"&& password1=="123456"){
        alert("iniciastes Sesion")
        window.location="../Usuario/Usuario2.html"
       
    }else{ 
        alert("Contraseña Incorrecta")
    }

}
function registro(){


    user= document.getElementById("usuario").value;
    correo=document.getElementById("correo").value
    password=document.getElementById("contraseña").value;

    if(user!=null  && correo != null && password !=null){
        alert(" Creastes Cuenta")
    }else{
        alert("No se creo la Cuenta")
    }


}
function IMC(){

    var calculo
    peso= document.getElementById("peso").value;
    altura=document.getElementById("altura").value
    let imc=""

    calculo=((peso)/(altura*altura))
    if(calculo<18.5){
        
    }else if(calculo<24.9){
        imc=Calculo
            
    }else if(calculo<29.9){
        imc=calculo
    }else if(calculo<34.9){
        imc=calculo
    }else if(calculo<39.9){
        imc=calculo
    }else if(calculo>39.9){
        imc=calculo
    }
   document.getElementById("resultado").innerText=imc

}