import "./Nutricion.css"
import Image from "../Imagenes/Logo2.png"
import Image2 from "../Imagenes/Recetas2.jpeg"
import Image3 from "../Imagenes/importancia-de-la-nutricion.jpg"

const Usuario=()=>{
     

    return(
   <div className="PagePrincipal"> 
    
    
    <div class="encabezado">
        <header>
        <img src={Image}/>
           <nav>
              <ul class="Menu">
          
                 <li><a href="#">Home</a></li>
                 <li><a href="#">Nutricion</a></li>
                 <li><a href="#">Rutinas</a></li>
                 <button id ="botones" class="botones" ><a href="#">Login</a></button>
          
              </ul>
            </nav>
            
         </header>
     </div >
     <div class="Recomendaciones">
      
           <div class="receptas">
               
                <section class="Dos">
                  <br/>
                  <a ><img src={Image2}/></a>
                </section>
            </div>
    

           <div class="Alimentacion">
              <section>
      
                <br/><br/>
                <a ><img src={Image3}/></a>
                
              </section>
            </div>

      </div>
    
    <div class="Pie">
        <footer>
          <p></p>
        </footer>


        </div>
     
    </div>

    )
    
}

export default Usuario ;