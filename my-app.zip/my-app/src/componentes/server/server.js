const express = require('express');
const mysql = require('mysql');

const app = express();

// Crear una piscina de conexiones a la base de datos
const pool = mysql.createPool({
  connectionLimit: 10,
  host: 'localhost',
  user: 'root',
  password: 'soporte',
  database: 'gimnasio'
});

app.use(express.json());

// Manejar la solicitud de registro de nuevos usuarios
app.post('/usuarios', (req, res) => {
  const { usuario, correo, contraseña } = req.body;
  
  // Obtener una conexión de la piscina de conexiones
  pool.getConnection((error, conexion) => {
    if (error) {
      console.error(error);
      res.status(500).json({ mensaje: 'Error al crear usuario' });
    } else {
      // Insertar el nuevo usuario en la tabla de usuarios
      conexion.query(
        'INSERT INTO usuarios (usuario, correo, contraseña) ',
        [usuario, correo, contraseña],
        (error, resultados) => {
          // Liberar la conexión a la piscina de conexiones
          conexion.release();
          
          if (error) {
            console.error(error);
            res.status(500).json({ mensaje: 'Error al crear usuario' });
          } else {
            res.status(201).json({ mensaje: 'Usuario creado exitosamente' });
          }
        }
      );
    }
  });
});

app.listen(3000, () => {
  console.log('Servidor iniciado en el puerto 3000');
});
