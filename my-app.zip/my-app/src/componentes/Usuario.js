import "./Usuarios.css"
import Image from "../Imagenes/Logo2.png"
import Image2 from "../Imagenes/cuenta 2.png"
import Image3 from "../Imagenes/Calculadora.png"
import Image4 from "../Imagenes/platosaludable-Recuperado.jpg"
import Image5 from "../Imagenes/Rutinas 4.jpg"
import Image6 from "../Imagenes/Dieta 1.jpg"

const Usuario=()=>{

    
     

    return(
   <div className="PagePrincipal"> 
    
     <div class="encabezado">
        <header>
        <img src={Image}/>
           <nav>
              <ul class="Menu">
          
                 <li><a href="#">Home</a></li>
                 <li><a href="#">Nutricion</a></li>
                 <li><a href="#">Rutinas</a></li>
                 <li><a href="#">Informes</a></li>
              </ul>
            </nav>
            <div class="ImagenLogo"> <img src={Image2}/></div>
           
         </header>
     </div >
     <div class="Unidad">
            <div class="Uno">
                <div class="Uno-1">
                    <a href="#"><img src={Image3}/></a>
                </div>
                <div class="Uno-2">
                    <img src={Image4}/>
                </div>
                
            </div>

            <div class="Dos">
                <img src={Image5}/>
            </div>
            

            <div class="Tres">
                <img src={Image6}/>
            </div>
     </div>
     
   
    <div class="Pie">
        <footer>
          <p></p>
        </footer>

     
        </div>
    </div>
   

    )
    
}

export default Usuario ;