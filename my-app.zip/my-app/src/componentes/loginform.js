import React, { useState } from "react";
import "./loginform.css";

const LoginForm = () => {
  const [popupStyle, showPopup] = useState("hide");

  const login = () => {
    const usuario = document.getElementById("usuario").value;
    const password = document.getElementById("contraseña").value;

    if (usuario !== "" && password !== "") {
      fetch("http://localhost:3000/usuarios", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ usuario, password }),
      })
        .then((response) => response.json())
        .then((data) => {
          if (data.length > 0 && data[0].usuario === usuario && data[0].password === password) {
            alert("Iniciaste sesión");
            window.location = "#";
          } else {
            alert("Contraseña Incorrecta");
          }
        })
        .catch((error) => console.error(error));
    } else {
      alert("Debes completar todos los campos");
      popup();
    }
  };

  const popup = () => {
    showPopup("login-popup");
    setTimeout(() => showPopup("hide"), 3000);
  };

  return (
    <div className="cover">
      <h1>Login</h1>
      <input type="text" placeholder="Usuario" id="usuario" />
      <input type="Password" placeholder="password" id="contraseña" />
      <div className="login-btn" onClick={login}>
        Login
      </div>
      <p className="text">No tienes Cuenta? Registrate </p>

      <div className="alt-login">
        <div className="facebook"></div>
        <div className="google"></div>
      </div>

      <div className={popupStyle}>
        <h3>Login Fail</h3>
        <p>Username or password incorrect</p>
      </div>
    </div>
  );
};

export default LoginForm;
