
import "./Menu.css"
import Image from "../Imagenes/Logo2.png"
import { Link } from 'react-router-dom';


const Menu = () => {
  return (
    <div className="PaginaPrincipal"> 
      <div class="encabezado">
        <header>
          <img src={Image}/>
          <ul class="Menu">
            <li><Link to="/">Home</Link></li>
            <li><Link to="/nutricion">Nutricion</Link></li>
            <li><Link to="/entrenamiento">Rutinas</Link></li>
            <li className ="botones"><Link to="/login">Login</Link></li>
          </ul>
        </header>
      </div>
      <div class="Pie">
        <footer>
          <p></p>
        </footer>
      </div>
    </div>
  );
}


export default Menu ;