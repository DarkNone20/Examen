
import './App.css';
//import DOS from './componentes/loginform';
import DOS from './componentes/registro';
//import DOS from "./componentes/Home"
//import DOS from "./componentes/Usuario"
//import DOS from "./componentes/Nutricion"
 //import DOS from "./componentes/Entrenamiento"

function App() {
  return (
    <div className="page">
      <DOS/>
    </div>
  );
}

export default App;
